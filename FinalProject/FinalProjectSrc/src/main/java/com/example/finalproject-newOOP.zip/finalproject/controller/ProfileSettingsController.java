package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.dao.DBConnection;
import com.example.finalproject.security.AuthGuard;
import com.example.finalproject.security.JwtService;
import com.example.finalproject.security.Session;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.*;

public class ProfileSettingsController {

    private TextField nameField;
    private TextField emailField;
    private TextField addressField;
    private PasswordField oldPassField;
    private PasswordField newPassField;
    private Label msgLabel;

    public Parent createView() {
        AuthGuard.requireLogin();

        BorderPane root = new BorderPane();
        root.setPrefSize(600, 400);

        // Create top bar
        HBox topBar = createTopBar();
        root.setTop(topBar);

        // Create center form
        GridPane formGrid = createFormGrid();
        root.setCenter(formGrid);

        // Load user data
        loadUserData();

        return root;
    }

    private HBox createTopBar() {
        HBox topBar = new HBox();
        topBar.setSpacing(20);
        topBar.setStyle("-fx-background-color:#0078D7;-fx-padding:12;");

        Label titleLabel = new Label("👤 Profile Settings");
        titleLabel.setStyle("-fx-text-fill:white;-fx-font-size:18;-fx-font-weight:bold;");

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button backBtn = new Button("⬅ Back");
        backBtn.setStyle("-fx-background-color:white;-fx-text-fill:#0078D7;-fx-font-weight:bold;");
        backBtn.setOnAction(e -> onBack());

        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-background-color:#d9534f;-fx-text-fill:white;-fx-font-weight:bold;");
        logoutBtn.setOnAction(e -> onLogout());

        topBar.getChildren().addAll(titleLabel, spacer, backBtn, logoutBtn);

        return topBar;
    }

    private GridPane createFormGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);
        grid.setStyle("-fx-padding:20;");

        // Column constraints
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setHalignment(HPos.RIGHT);
        col1.setMinWidth(120);

        ColumnConstraints col2 = new ColumnConstraints();
        col2.setHgrow(Priority.ALWAYS);

        grid.getColumnConstraints().addAll(col1, col2);

        // Row 0: Full Name
        Label nameLabel = new Label("Full Name:");
        nameField = new TextField();
        grid.add(nameLabel, 0, 0);
        grid.add(nameField, 1, 0);

        // Row 1: Email
        Label emailLabel = new Label("Email:");
        emailField = new TextField();
        emailField.setEditable(false);
        grid.add(emailLabel, 0, 1);
        grid.add(emailField, 1, 1);

        // Row 2: Address
        Label addressLabel = new Label("Address:");
        addressField = new TextField();
        grid.add(addressLabel, 0, 2);
        grid.add(addressField, 1, 2);

        // Row 3: Old Password
        Label oldPassLabel = new Label("Old Password:");
        oldPassField = new PasswordField();
        grid.add(oldPassLabel, 0, 3);
        grid.add(oldPassField, 1, 3);

        // Row 4: New Password
        Label newPassLabel = new Label("New Password:");
        newPassField = new PasswordField();
        grid.add(newPassLabel, 0, 4);
        grid.add(newPassField, 1, 4);

        // Row 5: Save Button
        Button saveBtn = new Button("💾 Save Changes");
        saveBtn.setStyle("-fx-background-color:#0078D7; -fx-text-fill:white; -fx-font-weight:bold;");
        saveBtn.setOnAction(e -> onSave());
        grid.add(saveBtn, 1, 5);

        // Row 6: Message Label
        msgLabel = new Label();
        msgLabel.setStyle("-fx-text-fill:red; -fx-font-weight:bold;");
        grid.add(msgLabel, 1, 6);

        return grid;
    }

    private void loadUserData() {
        try {
            int userId = JwtService.getUserId(Session.getToken());
            Connection conn = DBConnection.getInstance();
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT name, email, address FROM users WHERE id=?");
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                nameField.setText(rs.getString("name"));
                emailField.setText(rs.getString("email"));
                addressField.setText(rs.getString("address"));
            }
        } catch (Exception e) {
            msgLabel.setText("⚠️ Error loading profile data.");
            e.printStackTrace();
        }
    }

    private void onSave() {
        try {
            int userId = JwtService.getUserId(Session.getToken());
            Connection conn = DBConnection.getInstance();

            // --- Fetch user and verify old password ---
            PreparedStatement check = conn.prepareStatement("SELECT password_hash FROM users WHERE id=?");
            check.setInt(1, userId);
            ResultSet rs = check.executeQuery();
            if (!rs.next()) {
                msgLabel.setText("❌ User not found.");
                return;
            }

            String oldHash = rs.getString("password_hash");
            if (!BCrypt.checkpw(oldPassField.getText(), oldHash)) {
                msgLabel.setText("❌ Incorrect old password.");
                return;
            }

            // --- Get form values ---
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String address = addressField.getText().trim();
            String newPass = newPassField.getText().trim();

            // ---------- VALIDATION ----------
            if (name.isEmpty() || email.isEmpty() || address.isEmpty()) {
                msgLabel.setText("⚠️ All fields are required.");
                return;
            }

            // ✅ Email format check
            if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
                msgLabel.setText("⚠️ Invalid email format.");
                return;
            }

            // ✅ Password strength (only if changing password)
            if (!newPass.isEmpty()) {
                if (newPass.length() < 8
                        || !newPass.matches(".*[A-Z].*")
                        || !newPass.matches(".*[a-z].*")
                        || !newPass.matches(".*\\d.*")
                        || !newPass.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
                    msgLabel.setText("⚠️ Password must have upper, lower, number & special char.");
                    return;
                }
            }

            // --- Update query ---
            String sql;
            PreparedStatement ps;
            if (newPass.isEmpty()) {
                sql = "UPDATE users SET name=?, email=?, address=? WHERE id=?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, address);
                ps.setInt(4, userId);
            } else {
                sql = "UPDATE users SET name=?, email=?, address=?, password_hash=? WHERE id=?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, address);
                ps.setString(4, BCrypt.hashpw(newPass, BCrypt.gensalt()));
                ps.setInt(5, userId);
            }

            int updated = ps.executeUpdate();
            if (updated > 0) {
                msgLabel.setStyle("-fx-text-fill:green;");
                msgLabel.setText("✅ Profile updated successfully!");
            } else {
                msgLabel.setStyle("-fx-text-fill:red;");
                msgLabel.setText("⚠️ No changes made.");
            }

        } catch (Exception e) {
            msgLabel.setStyle("-fx-text-fill:red;");
            msgLabel.setText("⚠️ Error saving changes.");
            e.printStackTrace();
        }
    }


    private void onBack() {
        HelloApplication.setRoot(new CustomerHomeController());
    }

    private void onLogout() {
        Session.clear();
        HelloApplication.setRoot(new LoginController());
    }
}
