package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.dao.OrderDao;
import com.example.finalproject.model.Order;
import com.example.finalproject.model.OrderItem;
import com.example.finalproject.model.Product;
import com.example.finalproject.security.AuthGuard;
import com.example.finalproject.security.JwtService;
import com.example.finalproject.security.Session;
import com.example.finalproject.service.CartService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CheckoutController {

    private Label totalLabel;

    private final CartService cartService = CartService.getInstance();
    private final OrderDao orderDao = new OrderDao();

    public Parent createView() {
        AuthGuard.requireLogin();

        AnchorPane root = new AnchorPane();
        root.setPrefSize(800, 600);

        // Create main VBox
        VBox mainBox = new VBox();
        mainBox.setAlignment(Pos.CENTER);
        mainBox.setSpacing(25);
        AnchorPane.setTopAnchor(mainBox, 20.0);
        AnchorPane.setBottomAnchor(mainBox, 20.0);
        AnchorPane.setLeftAnchor(mainBox, 20.0);
        AnchorPane.setRightAnchor(mainBox, 20.0);

        // Title
        Label titleLabel = new Label("🧾 Checkout");
        titleLabel.getStyleClass().add("title-label");

        // Order Summary Box
        VBox orderBox = new VBox();
        orderBox.setSpacing(15);
        orderBox.getStyleClass().add("auth-card");
        orderBox.setMaxWidth(400);
        orderBox.setPadding(new Insets(20));

        Label reviewLabel = new Label("Review Your Order");
        reviewLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        totalLabel = new Label();
        totalLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #333;");

        Button confirmBtn = new Button("Confirm Order ✅");
        confirmBtn.setPrefWidth(200);
        confirmBtn.setOnAction(e -> onConfirmOrder());

        Button backBtn = new Button("Back to Shop");
        backBtn.setPrefWidth(200);
        backBtn.setStyle("-fx-background-color: gray; -fx-text-fill: white;");
        backBtn.setOnAction(e -> onBack());

        orderBox.getChildren().addAll(reviewLabel, totalLabel, confirmBtn, backBtn);

        mainBox.getChildren().addAll(titleLabel, orderBox);
        root.getChildren().add(mainBox);

        // Initialize data
        double total = cartService.getTotal();
        totalLabel.setText(String.format("Total: $%.2f", total));

        return root;
    }

    private void onConfirmOrder() {
        try {
            int userId = JwtService.getUserId(Session.getToken());
            Map<Product, Integer> cartItems = cartService.getItems();

            if (cartItems.isEmpty()) {
                showAlert("Your cart is empty!");
                return;
            }

            // Prepare order items
            // CheckoutController.onConfirmOrder()
            List<OrderItem> orderItems = new ArrayList<>();
            for (var entry : cartItems.entrySet()) {
                Product p = entry.getKey();
                int qty = entry.getValue();
                double unit = p.getEffectivePrice();        // 🔸 use discounted price
                orderItems.add(new OrderItem(0, 0, p.getId(), qty, unit));
            }

            Order order = new Order();
            order.setUserId(userId);
            order.setItems(orderItems);
            order.setTotal(cartService.getTotal());          // 🔸 now discounted
            order.setStatus("PENDING");
            orderDao.saveOrder(order);


            // Clear cart
            cartService.clear();

            showAlert("✅ Order placed successfully!");
            HelloApplication.setRoot(new CustomerHomeController());
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("❌ Error saving order: " + e.getMessage());
        }
    }

    private void onBack() {
        HelloApplication.setRoot(new CartController());
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
