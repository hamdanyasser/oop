package com.example.finalproject.controller;

import com.example.finalproject.dao.ReviewDao;
import com.example.finalproject.model.Review;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class ProductReviewsController {

    private Label productTitle;
    private TableView<Review> reviewTable;
    private TableColumn<Review, String> colUser;
    private TableColumn<Review, Number> colRating;
    private TableColumn<Review, String> colComment;
    private TableColumn<Review, String> colDate;

    private final ReviewDao dao = new ReviewDao();

    public Parent createView() {
        // Main container
        VBox root = new VBox();
        root.setSpacing(15);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        // Product title
        productTitle = new Label();
        productTitle.setStyle("-fx-font-size:18;-fx-font-weight:bold;");

        // Table view
        reviewTable = new TableView<>();
        reviewTable.setPrefWidth(600);
        reviewTable.setPrefHeight(400);

        // Table columns
        colUser = new TableColumn<>("User");
        colUser.setPrefWidth(150);

        colRating = new TableColumn<>("Rating");
        colRating.setPrefWidth(100);

        colComment = new TableColumn<>("Comment");
        colComment.setPrefWidth(250);

        colDate = new TableColumn<>("Date");
        colDate.setPrefWidth(150);

        reviewTable.getColumns().addAll(colUser, colRating, colComment, colDate);

        // Add all to root
        root.getChildren().addAll(productTitle, reviewTable);

        return root;
    }

    public void setProduct(int productId, String productName) {
        productTitle.setText("Reviews for " + productName);

        colUser.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getUsername()));
        colRating.setCellValueFactory(c -> new javafx.beans.property.SimpleIntegerProperty(c.getValue().getRating()));
        colComment.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getComment()));
        colDate.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getCreatedAt().toString()));

        reviewTable.setItems(FXCollections.observableArrayList(dao.getReviewsByProductWithUser(productId)));
    }
}
