package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.model.Order;
import com.example.finalproject.security.AuthGuard;
import com.example.finalproject.security.Session;
import com.example.finalproject.service.InvoiceService;
import com.example.finalproject.service.OrderService;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class AdminOrdersController {

    private TableView<Order> orderTable;
    private TableColumn<Order, Integer> colId;
    private TableColumn<Order, Integer> colUser;
    private TableColumn<Order, Double> colTotal;
    private TableColumn<Order, String> colStatus;
    private TableColumn<Order, String> colDate;
    private TextField searchField;
    private ComboBox<String> statusFilter;

    private final OrderService service = new OrderService();

    public Parent createView() {
        AuthGuard.requireLogin();

        BorderPane root = new BorderPane();
        root.setPrefSize(900, 600);

        // Top bar
        HBox topBar = new HBox();
        topBar.setSpacing(20);
        topBar.setStyle("-fx-background-color:#0078D7;-fx-padding:12;");

        Label titleLabel = new Label("📦 Orders Management");
        titleLabel.setStyle("-fx-text-fill:white;-fx-font-size:20;-fx-font-weight:bold;");

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button backBtn = new Button("⬅ Back to Products");
        backBtn.setStyle("-fx-background-color:white;-fx-text-fill:#0078D7;-fx-font-weight:bold;");
        backBtn.setOnAction(e -> goProducts());

        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-background-color:#d9534f;-fx-text-fill:white;-fx-font-weight:bold;");
        logoutBtn.setOnAction(e -> logout());

        topBar.getChildren().addAll(titleLabel, spacer, backBtn, logoutBtn);
        root.setTop(topBar);

        // Center content
        VBox centerBox = new VBox();
        centerBox.setSpacing(15);
        centerBox.setAlignment(Pos.CENTER);
        centerBox.setStyle("-fx-padding:20;");

        // Search and filter bar
        HBox filterBar = new HBox();
        filterBar.setSpacing(10);
        filterBar.setAlignment(Pos.CENTER_LEFT);

        Label searchLabel = new Label("🔍 Search:");
        searchField = new TextField();
        searchField.setPromptText("Enter Order ID or User ID");
        searchField.setPrefWidth(180);

        Label filterLabel = new Label("Filter by Status:");
        statusFilter = new ComboBox<>();
        statusFilter.setPrefWidth(150);
        statusFilter.getItems().addAll("ALL", "PENDING", "DELIVERED");
        statusFilter.setValue("ALL");

        Button applyBtn = new Button("Apply Filter");
        applyBtn.setOnAction(e -> onApplyFilter());

        Button resetBtn = new Button("Reset");
        resetBtn.setOnAction(e -> onResetFilter());

        filterBar.getChildren().addAll(searchLabel, searchField, filterLabel, statusFilter, applyBtn, resetBtn);

        // Table
        orderTable = new TableView<>();
        orderTable.setPrefWidth(850);
        orderTable.setPrefHeight(450);

        colId = new TableColumn<>("Order ID");
        colId.setPrefWidth(80);
        colId.setCellValueFactory(c -> new javafx.beans.property.SimpleIntegerProperty(c.getValue().getId()).asObject());

        colUser = new TableColumn<>("User ID");
        colUser.setPrefWidth(100);
        colUser.setCellValueFactory(c -> new javafx.beans.property.SimpleIntegerProperty(c.getValue().getUserId()).asObject());

        colTotal = new TableColumn<>("Total ($)");
        colTotal.setPrefWidth(150);
        colTotal.setCellValueFactory(c -> new javafx.beans.property.SimpleDoubleProperty(c.getValue().getTotal()).asObject());

        colStatus = new TableColumn<>("Status");
        colStatus.setPrefWidth(150);
        colStatus.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getStatus()));

        colDate = new TableColumn<>("Created At");
        colDate.setPrefWidth(250);
        colDate.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getCreatedAt().toString()));

        orderTable.getColumns().addAll(colId, colUser, colTotal, colStatus, colDate);

        // Action buttons
        HBox actionBar = new HBox();
        actionBar.setSpacing(15);
        actionBar.setAlignment(Pos.CENTER);

        Button deliverBtn = new Button("✅ Mark Delivered");
        deliverBtn.setOnAction(e -> onDeliver());

        Button deleteBtn = new Button("🗑 Delete Order");
        deleteBtn.setOnAction(e -> onDelete());

        Button reportsBtn = new Button("📊 View Reports");
        reportsBtn.setOnAction(e -> onViewReports());

        Button exportCSVBtn = new Button("⬇ Export CSV");
        exportCSVBtn.setOnAction(e -> onExportCSV());

        Button invoiceBtn = new Button("📄 Download Invoice");
        invoiceBtn.setOnAction(e -> onDownloadInvoice());

        Button exportPDFBtn = new Button("🧾 Export PDF");
        exportPDFBtn.setOnAction(e -> onExportPDF());

        Button viewItemsBtn = new Button("📦 View Items");
        viewItemsBtn.setOnAction(e -> onViewItems());

        actionBar.getChildren().addAll(deliverBtn, deleteBtn, reportsBtn, exportCSVBtn, invoiceBtn, exportPDFBtn, viewItemsBtn);

        centerBox.getChildren().addAll(filterBar, orderTable, actionBar);
        root.setCenter(centerBox);

        // Load data
        loadData();

        return root;
    }

    private void loadData() {
        orderTable.setItems(FXCollections.observableArrayList(service.getAllOrders()));
    }

    private void onDeliver() {
        Order selected = orderTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            service.markDelivered(selected.getId());
            loadData();
        } else showAlert("Select an order to mark as delivered.");
    }

    private void onDelete() {
        Order selected = orderTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            service.deleteOrder(selected.getId());
            loadData();
        } else showAlert("Select an order to delete.");
    }

    private void onApplyFilter() {
        String keyword = searchField.getText().trim();
        String status = statusFilter.getValue();

        orderTable.setItems(FXCollections.observableArrayList(service.filterOrders(keyword, status)));
    }

    private void onResetFilter() {
        searchField.clear();
        statusFilter.setValue("ALL");
        loadData();
    }

    private void onViewReports() {
        HelloApplication.setRoot(new AdminReportsController());
    }

    private void onExportCSV() {
        try {
            java.io.File file = new java.io.File("orders_export.csv");
            try (java.io.FileWriter writer = new java.io.FileWriter(file)) {
                writer.write("OrderID,UserID,Total,Status,CreatedAt\n");
                for (var order : service.getAllOrders()) {
                    writer.write(order.getId() + "," +
                            order.getUserId() + "," +
                            order.getTotal() + "," +
                            order.getStatus() + "," +
                            order.getCreatedAt() + "\n");
                }
            }
            showAlert("✅ Orders exported to: " + file.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("❌ Error exporting CSV: " + e.getMessage());
        }
    }

    private void onExportPDF() {
        try {
            String pdfPath = "orders_export.pdf";

            com.itextpdf.text.Document doc = new com.itextpdf.text.Document();
            com.itextpdf.text.pdf.PdfWriter.getInstance(doc,
                    new java.io.FileOutputStream(pdfPath));
            doc.open();

            doc.add(new com.itextpdf.text.Paragraph("Orders Report"));
            doc.add(new com.itextpdf.text.Paragraph(" "));

            com.itextpdf.text.pdf.PdfPTable table = new com.itextpdf.text.pdf.PdfPTable(5);
            table.addCell("Order ID");
            table.addCell("User ID");
            table.addCell("Total");
            table.addCell("Status");
            table.addCell("Created At");

            for (var o : service.getAllOrders()) {
                table.addCell(String.valueOf(o.getId()));
                table.addCell(String.valueOf(o.getUserId()));
                table.addCell(String.format("%.2f", o.getTotal()));
                table.addCell(o.getStatus());
                table.addCell(o.getCreatedAt().toString());
            }

            doc.add(table);
            doc.close();

            showAlert("✅ PDF generated at: " + pdfPath);
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("❌ Error generating PDF: " + e.getMessage());
        }
    }

    private void goProducts() {
        HelloApplication.setRoot(new AdminProductsController());
    }

    private void onDownloadInvoice() {
        Order selected = orderTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select an order first.");
            return;
        }

        try {
            java.nio.file.Path pdf = new InvoiceService().generateInvoice(selected.getId());
            showAlert("✅ Invoice saved to: " + pdf.toString());
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("❌ Failed to generate invoice: " + e.getMessage());
        }
    }

    private void logout() {
        Session.clear();
        HelloApplication.setRoot(new LoginController());
    }

    private void onViewItems() {
        Order selected = orderTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select an order first.");
            return;
        }

        try {
            OrderItemsPopupController controller = new OrderItemsPopupController();
            Parent root = controller.createView();
            controller.setOrderId(selected.getId());

            Stage stage = new Stage();
            stage.setTitle("Order #" + selected.getId() + " Details");
            Scene scene = new Scene(root);
            scene.getStylesheets().add(HelloApplication.class.getResource("view/style.css").toExternalForm());
            stage.setScene(scene);

            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setResizable(false);

            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error loading order details: " + e.getMessage());
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Info");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
