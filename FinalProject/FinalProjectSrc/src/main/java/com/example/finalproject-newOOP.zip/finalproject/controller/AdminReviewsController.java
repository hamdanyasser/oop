package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.dao.ReviewDao;
import com.example.finalproject.model.Review;
import com.example.finalproject.security.AuthGuard;
import com.example.finalproject.security.Session;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.List;

public class AdminReviewsController {

    private TableView<Review> reviewTable;
    private TableColumn<Review, String> colUser;
    private TableColumn<Review, String> colProduct;
    private TableColumn<Review, Number> colRating;
    private TableColumn<Review, String> colComment;
    private TableColumn<Review, String> colDate;
    private TextField searchField;

    private final ReviewDao dao = new ReviewDao();
    private ObservableList<Review> reviewList;

    public Parent createView() {
        AuthGuard.requireLogin();

        BorderPane root = new BorderPane();
        root.setPrefSize(900, 600);

        // Top bar
        HBox topBar = new HBox();
        topBar.setSpacing(15);
        topBar.setStyle("-fx-background-color:#0078D7;-fx-padding:12;");

        Label titleLabel = new Label("⭐ Manage Reviews");
        titleLabel.setStyle("-fx-text-fill:white;-fx-font-size:20;-fx-font-weight:bold;");

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button backBtn = new Button("⬅ Back");
        backBtn.setStyle("-fx-background-color:white;-fx-text-fill:#0078D7;-fx-font-weight:bold;");
        backBtn.setOnAction(e -> onBack());

        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-background-color:#d9534f;-fx-text-fill:white;-fx-font-weight:bold;");
        logoutBtn.setOnAction(e -> onLogout());

        topBar.getChildren().addAll(titleLabel, spacer, backBtn, logoutBtn);
        root.setTop(topBar);

        // Center content
        VBox centerBox = new VBox();
        centerBox.setSpacing(15);
        centerBox.setAlignment(Pos.CENTER);
        centerBox.setStyle("-fx-padding:20;");

        // Search bar
        HBox searchBar = new HBox();
        searchBar.setSpacing(10);
        searchBar.setAlignment(Pos.CENTER_LEFT);

        Label searchLabel = new Label("Search:");
        searchField = new TextField();
        searchField.setPromptText("Type username, product, or comment...");
        searchField.setPrefWidth(300);

        searchBar.getChildren().addAll(searchLabel, searchField);

        // Table
        reviewTable = new TableView<>();
        reviewTable.setPrefWidth(850);
        reviewTable.setPrefHeight(450);

        colUser = new TableColumn<>("User");
        colUser.setPrefWidth(150);
        colUser.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getUsername()));

        colProduct = new TableColumn<>("Product");
        colProduct.setPrefWidth(200);
        colProduct.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getProductName()));

        colRating = new TableColumn<>("Rating");
        colRating.setPrefWidth(100);
        colRating.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getRating()));

        colComment = new TableColumn<>("Comment");
        colComment.setPrefWidth(250);
        colComment.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getComment()));

        colDate = new TableColumn<>("Date");
        colDate.setPrefWidth(150);
        colDate.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(
                data.getValue().getCreatedAt() != null ? data.getValue().getCreatedAt().toString() : ""));

        reviewTable.getColumns().addAll(colUser, colProduct, colRating, colComment, colDate);

        // Delete button
        Button deleteBtn = new Button("🗑 Delete Selected");
        deleteBtn.setOnAction(e -> onDelete());

        centerBox.getChildren().addAll(searchBar, reviewTable, deleteBtn);
        root.setCenter(centerBox);

        // Load data
        initializeData();

        return root;
    }

    private void initializeData() {
        // Load data
        List<Review> reviews = dao.getAllReviewsForAdmin();
        reviewList = FXCollections.observableArrayList(reviews);

        // Enable search filtering
        FilteredList<Review> filteredList = new FilteredList<>(reviewList, b -> true);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            String filter = newVal.toLowerCase().trim();
            filteredList.setPredicate(r -> {
                if (filter.isEmpty()) return true;
                return r.getUsername().toLowerCase().contains(filter)
                        || r.getProductName().toLowerCase().contains(filter)
                        || r.getComment().toLowerCase().contains(filter)
                        || String.valueOf(r.getRating()).contains(filter);
            });
        });

        SortedList<Review> sortedList = new SortedList<>(filteredList);
        sortedList.comparatorProperty().bind(reviewTable.comparatorProperty());
        reviewTable.setItems(sortedList);
    }

    private void onDelete() {
        Review selected = reviewTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a review to delete.");
            return;
        }

        try {
            java.sql.Connection conn = com.example.finalproject.dao.DBConnection.getInstance();
            java.sql.PreparedStatement ps = conn.prepareStatement("DELETE FROM review WHERE id=?");
            ps.setInt(1, selected.getId());
            ps.executeUpdate();

            reviewList.remove(selected);
            showAlert("Review deleted successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error deleting review: " + e.getMessage());
        }
    }

    private void onBack() {
        HelloApplication.setRoot(new AdminProductsController());
    }

    private void onLogout() {
        Session.clear();
        HelloApplication.setRoot(new LoginController());
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
