package com.example.finalproject.controller;

import com.example.finalproject.model.Review;
import com.example.finalproject.security.AuthGuard;
import com.example.finalproject.security.JwtService;
import com.example.finalproject.security.Session;
import com.example.finalproject.service.ReviewService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ReviewPopupController {
    private Label productLabel;
    private ChoiceBox<Integer> ratingChoice;
    private TextArea commentField;

    private final ReviewService service = new ReviewService();
    private int productId;

    public Parent createView() {
        AuthGuard.requireLogin();

        // Main container
        VBox root = new VBox();
        root.setSpacing(15);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        // Title
        Label titleLabel = new Label("⭐ Leave a Review");
        titleLabel.setStyle("-fx-font-size:18px;-fx-font-weight:bold;");

        // Product label
        productLabel = new Label();
        productLabel.setStyle("-fx-font-size:14px;");

        // Rating section
        HBox ratingBox = new HBox();
        ratingBox.setSpacing(10);
        ratingBox.setAlignment(Pos.CENTER);

        Label ratingLabel = new Label("Rating:");
        ratingChoice = new ChoiceBox<>();
        ratingChoice.getItems().addAll(1, 2, 3, 4, 5);
        ratingChoice.setValue(5);

        ratingBox.getChildren().addAll(ratingLabel, ratingChoice);

        // Comment field
        commentField = new TextArea();
        commentField.setPromptText("Write a comment...");
        commentField.setPrefRowCount(3);
        commentField.setPrefWidth(250);

        // Submit button
        Button submitBtn = new Button("Submit Review");
        submitBtn.setStyle("-fx-background-color:#0078D7;-fx-text-fill:white;");
        submitBtn.setOnAction(e -> onSubmit());

        // Add all to root
        root.getChildren().addAll(
            titleLabel,
            productLabel,
            ratingBox,
            commentField,
            submitBtn
        );

        return root;
    }

    public void setProduct(int id, String name) {
        this.productId = id;
        productLabel.setText("Reviewing: " + name);
    }

    private void onSubmit() {
        try {
            int rating = ratingChoice.getValue();
            String comment = commentField.getText();
            int userId = JwtService.getUserId(Session.getToken());

            Review r = new Review(0, productId, userId, rating, comment, null);
            service.addReview(r);

            showAlert("✅ Review added successfully!");
            ((Stage) productLabel.getScene().getWindow()).close();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("❌ Failed to submit review: " + e.getMessage());
        }
    }

    private void showAlert(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setContentText(msg);
        a.showAndWait();
    }
}
