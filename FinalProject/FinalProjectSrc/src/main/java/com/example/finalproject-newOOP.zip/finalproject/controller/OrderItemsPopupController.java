package com.example.finalproject.controller;

import com.example.finalproject.dao.DBConnection;
import com.example.finalproject.model.OrderItem;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderItemsPopupController {

    private Label orderTitle;
    private TableView<OrderItem> itemTable;
    private TableColumn<OrderItem, String> colProduct;
    private TableColumn<OrderItem, Integer> colQty;
    private TableColumn<OrderItem, Double> colPrice;
    private TableColumn<OrderItem, Double> colSubtotal;
    private Label totalLabel;
    private Label statusLabel;

    private int orderId;

    public Parent createView() {
        // Main container
        VBox root = new VBox();
        root.setSpacing(15);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        // Order title
        orderTitle = new Label("Order #0 - Items");
        orderTitle.setStyle("-fx-font-size:16; -fx-font-weight:bold;");

        // Table view
        itemTable = new TableView<>();
        itemTable.setPrefWidth(600);
        itemTable.setPrefHeight(300);

        // Table columns
        colProduct = new TableColumn<>("Product");
        colProduct.setPrefWidth(200);

        colQty = new TableColumn<>("Quantity");
        colQty.setPrefWidth(100);

        colPrice = new TableColumn<>("Price ($)");
        colPrice.setPrefWidth(150);

        colSubtotal = new TableColumn<>("Subtotal ($)");
        colSubtotal.setPrefWidth(150);

        itemTable.getColumns().addAll(colProduct, colQty, colPrice, colSubtotal);

        // Summary section
        HBox summaryBox = new HBox();
        summaryBox.setSpacing(30);
        summaryBox.setAlignment(Pos.CENTER_RIGHT);

        Label totalTextLabel = new Label("Total:");
        totalTextLabel.setStyle("-fx-font-weight:bold; -fx-font-size:14;");

        totalLabel = new Label();
        totalLabel.setStyle("-fx-text-fill:#0078D7; -fx-font-size:14;");

        Label statusTextLabel = new Label("Status:");
        statusTextLabel.setStyle("-fx-font-weight:bold; -fx-font-size:14;");

        statusLabel = new Label();
        statusLabel.setStyle("-fx-font-size:14; -fx-text-fill:#333;");

        summaryBox.getChildren().addAll(totalTextLabel, totalLabel, statusTextLabel, statusLabel);

        // Close button
        Button closeBtn = new Button("Close");
        closeBtn.setPrefWidth(150);
        closeBtn.setOnAction(e -> onClose());

        // Add all to root
        root.getChildren().addAll(orderTitle, itemTable, summaryBox, closeBtn);

        return root;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
        orderTitle.setText("Order #" + orderId + " - Items");
        loadItemsAndSummary();
    }

    private void loadItemsAndSummary() {
        List<OrderItem> items = new ArrayList<>();
        double total = 0.0;
        String status = "";

        try (Connection conn = DBConnection.getInstance()) {
            // 🧾 Get order details
            PreparedStatement psOrder = conn.prepareStatement("SELECT total, status FROM orders WHERE id=?");
            psOrder.setInt(1, orderId);
            ResultSet rsOrder = psOrder.executeQuery();
            if (rsOrder.next()) {
                total = rsOrder.getDouble("total");
                status = rsOrder.getString("status");
            }

            // 🛍 Get order items
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
            ps.setInt(1, orderId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                OrderItem item = new OrderItem(
                        rs.getInt("id"),
                        rs.getInt("order_id"),
                        rs.getInt("product_id"),
                        rs.getInt("quantity"),
                        rs.getDouble("price")
                );
                item.setProductName(rs.getString("name"));
                items.add(item);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // 🧮 Populate table
        ObservableList<OrderItem> data = FXCollections.observableArrayList(items);
        colProduct.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getProductName()));
        colQty.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getQuantity()).asObject());
        colPrice.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getPrice()).asObject());
        colSubtotal.setCellValueFactory(c -> new SimpleDoubleProperty(
                c.getValue().getPrice() * c.getValue().getQuantity()).asObject());

        itemTable.setItems(data);

        // 🧾 Update summary
        totalLabel.setText(String.format("$%.2f", total));
        statusLabel.setText(status);
        if ("DELIVERED".equalsIgnoreCase(status)) {
            statusLabel.setStyle("-fx-text-fill:green; -fx-font-weight:bold;");
        } else if ("PENDING".equalsIgnoreCase(status)) {
            statusLabel.setStyle("-fx-text-fill:orange; -fx-font-weight:bold;");
        } else {
            statusLabel.setStyle("-fx-text-fill:red; -fx-font-weight:bold;");
        }
    }

    private void onClose() {
        Stage stage = (Stage) orderTitle.getScene().getWindow();
        stage.close();
    }
}
