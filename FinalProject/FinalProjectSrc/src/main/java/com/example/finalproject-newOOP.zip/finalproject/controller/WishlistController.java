package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.dao.ProductDao;
import com.example.finalproject.dao.WishlistDao;
import com.example.finalproject.model.Product;
import com.example.finalproject.model.ShoppingCart;
import com.example.finalproject.security.AuthGuard;
import com.example.finalproject.security.Session;
import com.example.finalproject.service.CartService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

import java.util.List;

public class WishlistController {

    private FlowPane wishlistGrid;

    private final WishlistDao wishlistDao = new WishlistDao();
    private final ProductDao productDao = new ProductDao();
    private final CartService cartService = CartService.getInstance();

    public Parent createView() {
        AuthGuard.requireLogin();

        BorderPane root = new BorderPane();
        root.setPrefSize(800, 600);

        // Create top bar
        HBox topBar = createTopBar();
        root.setTop(topBar);

        // Create center content
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);

        wishlistGrid = new FlowPane();
        wishlistGrid.setHgap(15);
        wishlistGrid.setVgap(15);
        wishlistGrid.setAlignment(Pos.CENTER);
        wishlistGrid.setStyle("-fx-padding:15;");

        scrollPane.setContent(wishlistGrid);
        root.setCenter(scrollPane);

        // Initialize data
        loadWishlist();

        return root;
    }

    private HBox createTopBar() {
        HBox topBar = new HBox();
        topBar.setSpacing(10);
        topBar.setStyle("-fx-background-color:#0078D7; -fx-padding:10;");

        Label titleLabel = new Label("❤️ My Wishlist");
        titleLabel.setStyle("-fx-font-size:20px; -fx-text-fill:white; -fx-font-weight:bold;");

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button backBtn = new Button("⬅ Back");
        backBtn.setOnAction(e -> onBack());

        topBar.getChildren().addAll(titleLabel, spacer, backBtn);

        return topBar;
    }

    private void loadWishlist() {
        wishlistGrid.getChildren().clear();
        List<Product> products = wishlistDao.getUserWishlist(Session.getUserId());

        for (Product p : products) {
            VBox card = new VBox(8);
            card.setAlignment(Pos.CENTER);
            card.setPadding(new Insets(10));
            card.setStyle("-fx-background-color:white; -fx-border-color:#ddd; "
                    + "-fx-background-radius:8; -fx-border-radius:8;");
            card.setPrefWidth(180);

            // 🖼 Product Image
            ImageView image = new ImageView(new Image("file:" + p.getImagePath(), 100, 100, true, true));

            // 🏷 Product Info
            Label name = new Label(p.getName());
            name.setStyle("-fx-font-weight:bold;");
            Label price = new Label("$" + p.getPrice());
            Label stock = new Label("Stock: " + p.getStock());
            stock.setStyle("-fx-text-fill: gray; -fx-font-size: 11;");

            // 🔢 Quantity selector
            Label qtyLabel = new Label("Qty:");
            Spinner<Integer> qtySpinner = new Spinner<>();
            qtySpinner.setValueFactory(
                    new SpinnerValueFactory.IntegerSpinnerValueFactory(1, p.getStock(), 1)
            );
            qtySpinner.setPrefWidth(80);

            // 🛒 Add to Cart
            Button addToCart = new Button("🛒 Add to Cart");
            addToCart.setOnAction(e -> {
                int qty = qtySpinner.getValue();

                if (p.getStock() <= 0) {
                    showAlert("❌ Out of Stock", p.getName() + " is currently unavailable.");
                    return;
                }

                if (qty > p.getStock()) {
                    showAlert("⚠️ Not enough stock", "Only " + p.getStock() + " left for " + p.getName());
                    return;
                }

                // Add to Cart
                cartService.addItem(p, qty);
                ShoppingCart.addItem(p.getId(), p.getEffectivePrice(), qty, p.getStock());

                // Decrease stock in DB
                productDao.decreaseStock(p.getId(), qty);
                p.setStock(p.getStock() - qty);
                stock.setText("Stock: " + p.getStock());

                // Remove from wishlist
                wishlistDao.removeFromWishlist(Session.getUserId(), p.getId());
                loadWishlist();

                showAlert("✅ Added to Cart", qty + " × " + p.getName() + " added to your cart!");
            });

            // 🗑 Remove
            Button remove = new Button("🗑 Remove");
            remove.setOnAction(e -> {
                wishlistDao.removeFromWishlist(Session.getUserId(), p.getId());
                loadWishlist();
            });

            // 🧱 Layout
            card.getChildren().addAll(
                    image,
                    name,
                    price,
                    stock,
                    qtyLabel,
                    qtySpinner,
                    addToCart,
                    remove
            );
            wishlistGrid.getChildren().add(card);
        }
    }

    private void onBack() {
        HelloApplication.setRoot(new CustomerHomeController());
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
