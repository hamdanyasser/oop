package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.security.Session;
import com.example.finalproject.service.AuthService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class RegisterController {

    private TextField nameField, emailField, addressField;
    private PasswordField passwordField;
    private Label msgLabel;

    private final AuthService authService = new AuthService();

    public Parent createView() {
        // Create main container
        StackPane root = new StackPane();
        root.setPrefSize(800, 600);

        // Create outer VBox for centering
        VBox outerBox = new VBox();
        outerBox.setAlignment(Pos.CENTER);
        outerBox.setSpacing(20);

        // Create inner VBox (auth card)
        VBox authCard = new VBox();
        authCard.setAlignment(Pos.CENTER);
        authCard.setSpacing(12);
        authCard.setMaxWidth(400);
        authCard.getStyleClass().add("auth-card");
        authCard.setPadding(new Insets(30));

        // Title
        Label titleLabel = new Label("🧾 Register");
        titleLabel.getStyleClass().add("title-label");

        // Name field
        nameField = new TextField();
        nameField.setPromptText("Full Name");
        nameField.getStyleClass().add("text-field");

        // Email field
        emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.getStyleClass().add("text-field");

        // Password field
        passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.getStyleClass().add("password-field");

        // Address field
        addressField = new TextField();
        addressField.setPromptText("Address");
        addressField.getStyleClass().add("text-field");

        // Register button
        Button registerBtn = new Button("Register");
        registerBtn.setPrefWidth(200);
        registerBtn.setOnAction(e -> onRegister());

        // Back to Login hyperlink
        Hyperlink loginLink = new Hyperlink("Back to Login");
        loginLink.setOnAction(e -> goLogin());

        // Message label
        msgLabel = new Label();
        msgLabel.getStyleClass().add("error-label");

        // Add all to auth card
        authCard.getChildren().addAll(
            titleLabel,
            nameField,
            emailField,
            passwordField,
            addressField,
            registerBtn,
            loginLink,
            msgLabel
        );

        outerBox.getChildren().add(authCard);
        root.getChildren().add(outerBox);

        return root;
    }

    public void onRegister() {
        // clear previous message
        msgLabel.setText("");

        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();
        String address = addressField.getText().trim();

        // ---------- VALIDATION ----------
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || address.isEmpty()) {
            msgLabel.setText("All fields are required.");
            return;
        }

        // ✅ Email format check
        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            msgLabel.setText("Invalid email format.");
            return;
        }

        // ✅ Password strength: 8+, upper, lower, number, special
        if (password.length() < 8
                || !password.matches(".*[A-Z].*")
                || !password.matches(".*[a-z].*")
                || !password.matches(".*\\d.*")
                || !password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
            msgLabel.setText("Password must have upper, lower, number & special char.");
            return;
        }

        try {
            // ✅ Call AuthService (it throws if email already exists)
            String token = authService.register(name, email, password, address);

            msgLabel.setStyle("-fx-text-fill: green;");
            msgLabel.setText("Registration successful! Redirecting...");

            Session.setToken(token);
            HelloApplication.setRoot(new CustomerHomeController());

        } catch (Exception e) {
            msgLabel.setStyle("-fx-text-fill: red;");
            msgLabel.setText(e.getMessage());
        }
    }

    public void goLogin() {
        HelloApplication.setRoot(new LoginController());
    }
}
