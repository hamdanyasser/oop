package com.example.finalproject.controller;

import com.example.finalproject.dao.UserDao;
import com.example.finalproject.util.EmailSender;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import java.util.Random;

public class ForgotPasswordController {

    private TextField emailField;
    private TextField otpField;
    private PasswordField newPasswordField;
    private Label messageLabel;

    private String generatedOtp;
    private String targetEmail;

    public Parent createView() {
        VBox root = new VBox();
        root.setSpacing(10);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        // Title
        Label titleLabel = new Label("Forgot Password");
        titleLabel.setStyle("-fx-font-size:20;-fx-font-weight:bold;");

        // Email field
        emailField = new TextField();
        emailField.setPromptText("Enter your email");

        // Send OTP button
        Button sendOtpBtn = new Button("Send OTP");
        sendOtpBtn.setOnAction(e -> onSendOtp());

        // OTP field
        otpField = new TextField();
        otpField.setPromptText("Enter OTP");

        // New password field
        newPasswordField = new PasswordField();
        newPasswordField.setPromptText("New Password");

        // Reset password button
        Button resetBtn = new Button("Reset Password");
        resetBtn.setOnAction(e -> onResetPassword());

        // Message label
        messageLabel = new Label();
        messageLabel.setTextFill(javafx.scene.paint.Color.RED);

        root.getChildren().addAll(
            titleLabel,
            emailField,
            sendOtpBtn,
            otpField,
            newPasswordField,
            resetBtn,
            messageLabel
        );

        return root;
    }

    private void onSendOtp() {
        String email = emailField.getText().trim();
        if (email.isEmpty()) {
            messageLabel.setText("Enter your email.");
            return;
        }

        UserDao dao = new UserDao();
        if (!dao.emailExists(email)) {
            messageLabel.setText("No account found with that email.");
            return;
        }

        generatedOtp = String.valueOf(new Random().nextInt(900000) + 100000);
        targetEmail = email;

        boolean sent = EmailSender.sendEmail(email, "Password Reset OTP",
                "Your OTP code is: " + generatedOtp);

        messageLabel.setText(sent ? "OTP sent to your email." : "Failed to send email.");
    }

    private void onResetPassword() {
        if (!otpField.getText().equals(generatedOtp)) {
            messageLabel.setText("Invalid OTP.");
            return;
        }

        String newPass = newPasswordField.getText();
        if (newPass.length() < 6) {
            messageLabel.setText("Password too short.");
            return;
        }

        new UserDao().updatePassword(targetEmail, newPass);
        messageLabel.setText("Password reset successfully!");
    }
}
