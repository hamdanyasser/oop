package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.dao.OrderDao;
import com.example.finalproject.model.Order;
import com.example.finalproject.security.AuthGuard;
import com.example.finalproject.security.JwtService;
import com.example.finalproject.security.Session;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.*;
import java.util.List;
import java.util.stream.Collectors;

public class OrderHistoryController {

    private TableView<Order> orderTable;
    private TableColumn<Order, Integer> colId;
    private TableColumn<Order, Double> colTotal;
    private TableColumn<Order, String> colStatus;
    private TableColumn<Order, Timestamp> colDate;

    private final OrderDao orderDao = new OrderDao();

    public Parent createView() {
        AuthGuard.requireLogin();

        BorderPane root = new BorderPane();
        root.setPrefSize(900, 600);

        // Create top bar
        HBox topBar = createTopBar();
        root.setTop(topBar);

        // Create center content
        VBox centerContent = createCenterContent();
        root.setCenter(centerContent);

        // Initialize data
        loadOrders();

        return root;
    }

    private HBox createTopBar() {
        HBox topBar = new HBox();
        topBar.setSpacing(20);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setStyle("-fx-background-color:#0078D7;-fx-padding:12;");

        Label titleLabel = new Label("📦 Your Orders");
        titleLabel.setStyle("-fx-text-fill:white;-fx-font-size:20px;-fx-font-weight:bold;");

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button backBtn = new Button("🏠 Back to Shop");
        backBtn.setOnAction(e -> onBack());

        Button viewItemsBtn = new Button("📦 View Items");
        viewItemsBtn.setOnAction(e -> onViewItems());

        Button logoutBtn = new Button("Logout");
        logoutBtn.setOnAction(e -> onLogout());

        topBar.getChildren().addAll(titleLabel, spacer, backBtn, viewItemsBtn, logoutBtn);

        return topBar;
    }

    private VBox createCenterContent() {
        VBox centerContent = new VBox();
        centerContent.setSpacing(15);
        centerContent.setAlignment(Pos.CENTER);
        centerContent.setStyle("-fx-padding:20;");

        // Create table
        orderTable = new TableView<>();
        orderTable.setPrefWidth(750);
        orderTable.setPrefHeight(500);

        // Create columns
        colId = new TableColumn<>("Order ID");
        colId.setPrefWidth(100);
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));

        colTotal = new TableColumn<>("Total ($)");
        colTotal.setPrefWidth(150);
        colTotal.setCellValueFactory(new PropertyValueFactory<>("total"));

        colStatus = new TableColumn<>("Status");
        colStatus.setPrefWidth(150);
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        colDate = new TableColumn<>("Created At");
        colDate.setPrefWidth(200);
        colDate.setCellValueFactory(new PropertyValueFactory<>("createdAt"));

        orderTable.getColumns().addAll(colId, colTotal, colStatus, colDate);

        // Buttons row
        HBox buttonsRow = new HBox();
        buttonsRow.setSpacing(15);
        buttonsRow.setAlignment(Pos.CENTER);

        Button viewItemsBtn = new Button("📦 View Items");
        viewItemsBtn.setOnAction(e -> onViewItems());

        buttonsRow.getChildren().add(viewItemsBtn);

        centerContent.getChildren().addAll(orderTable, buttonsRow);

        return centerContent;
    }

    private void loadOrders() {
        int userId = JwtService.getUserId(Session.getToken());
        List<Order> allOrders = orderDao.findAll();

        // Filter only this user's orders
        List<Order> userOrders = allOrders.stream()
                .filter(o -> o.getUserId() == userId)
                .collect(Collectors.toList());

        ObservableList<Order> orders = FXCollections.observableArrayList(userOrders);
        orderTable.setItems(orders);
    }

    private void onBack() {
        HelloApplication.setRoot(new CustomerHomeController());
    }

    private void onViewItems() {
        Order selected = orderTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please select an order first.", ButtonType.OK);
            alert.showAndWait();
            return;
        }

        try {
            OrderItemsPopupController controller = new OrderItemsPopupController();
            Parent root = controller.createView();
            controller.setOrderId(selected.getId());

            Stage stage = new Stage();
            stage.setTitle("Order Details");
            Scene scene = new Scene(root);
            scene.getStylesheets().add(HelloApplication.class.getResource("view/style.css").toExternalForm());
            stage.setScene(scene);
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void onLogout() {
        Session.clear();
        HelloApplication.setRoot(new LoginController());
    }
}
