package com.example.finalproject.util;

public class Guard {
}
