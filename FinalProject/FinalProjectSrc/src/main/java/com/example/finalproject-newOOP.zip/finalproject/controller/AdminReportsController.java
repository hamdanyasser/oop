package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.dao.ReportDao;
import com.example.finalproject.model.TopProduct;
import com.example.finalproject.security.AuthGuard;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import com.example.finalproject.security.Session;
import javafx.scene.layout.*;

import java.io.FileWriter;
import java.util.List;

public class AdminReportsController {

    private Label totalRevenueLabel;
    private BarChart<String, Number> salesChart;
    private TableView<TopProduct> topProductsTable;
    private TableColumn<TopProduct, String> colProduct;
    private TableColumn<TopProduct, Integer> colQty;
    private TableColumn<TopProduct, Double> colRevenue;

    private final ReportDao dao = new ReportDao();

    public Parent createView() {
        AuthGuard.requireLogin();

        BorderPane root = new BorderPane();
        root.setPrefSize(950, 600);

        // Header
        HBox topBar = new HBox();
        topBar.setSpacing(20);
        topBar.setStyle("-fx-background-color:#0078D7;-fx-padding:12;");

        Label titleLabel = new Label("📊 Sales Dashboard");
        titleLabel.setStyle("-fx-text-fill:white;-fx-font-size:20;-fx-font-weight:bold;");

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button backBtn = new Button("⬅ Back to Orders");
        backBtn.setStyle("-fx-background-color:white;-fx-text-fill:#0078D7;-fx-font-weight:bold;");
        backBtn.setOnAction(e -> onBack());

        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-background-color:#d9534f;-fx-text-fill:white;-fx-font-weight:bold;");
        logoutBtn.setOnAction(e -> onLogout());

        topBar.getChildren().addAll(titleLabel, spacer, backBtn, logoutBtn);
        root.setTop(topBar);

        // Center content
        VBox centerBox = new VBox();
        centerBox.setSpacing(20);
        centerBox.setAlignment(Pos.CENTER);
        centerBox.setStyle("-fx-padding:20;");

        // Total revenue label
        totalRevenueLabel = new Label();
        totalRevenueLabel.setStyle("-fx-font-size:18;-fx-font-weight:bold;-fx-text-fill:#333;");

        // Daily Sales Chart
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Date");

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Revenue ($)");

        salesChart = new BarChart<>(xAxis, yAxis);
        salesChart.setPrefHeight(250);
        salesChart.setPrefWidth(800);

        // Top Products label
        Label topProductsLabel = new Label("🥇 Top Selling Products");
        topProductsLabel.setStyle("-fx-font-size:16;-fx-font-weight:bold;-fx-padding:10 0 0 0;");

        // Top Products Table
        topProductsTable = new TableView<>();
        topProductsTable.setPrefWidth(800);
        topProductsTable.setPrefHeight(200);

        colProduct = new TableColumn<>("Product");
        colProduct.setPrefWidth(300);
        colProduct.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getProductName()));

        colQty = new TableColumn<>("Quantity Sold");
        colQty.setPrefWidth(200);
        colQty.setCellValueFactory(c -> new javafx.beans.property.SimpleIntegerProperty(c.getValue().getQuantitySold()).asObject());

        colRevenue = new TableColumn<>("Revenue ($)");
        colRevenue.setPrefWidth(200);
        colRevenue.setCellValueFactory(c -> new javafx.beans.property.SimpleDoubleProperty(c.getValue().getRevenue()).asObject());

        topProductsTable.getColumns().addAll(colProduct, colQty, colRevenue);

        // Action buttons
        HBox actionBar = new HBox();
        actionBar.setSpacing(15);
        actionBar.setAlignment(Pos.CENTER);

        Button refreshBtn = new Button("🔄 Refresh");
        refreshBtn.setOnAction(e -> onRefresh());

        Button exportBtn = new Button("💾 Export CSV");
        exportBtn.setOnAction(e -> onExportCSV());

        actionBar.getChildren().addAll(refreshBtn, exportBtn);

        centerBox.getChildren().addAll(
            totalRevenueLabel,
            salesChart,
            topProductsLabel,
            topProductsTable,
            actionBar
        );

        root.setCenter(centerBox);

        // Load data
        loadData();

        return root;
    }

    private void loadData() {
        // Total revenue
        double total = dao.getTotalRevenue();
        totalRevenueLabel.setText("💰 Total Revenue (Delivered Orders): $" + String.format("%.2f", total));

        // Daily sales chart
        salesChart.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        dao.getDailySales().forEach(s -> series.getData().add(new XYChart.Data<>(s.getDate(), s.getRevenue())));
        series.setName("Daily Revenue");
        salesChart.getData().add(series);

        // Top-selling products
        topProductsTable.setItems(FXCollections.observableArrayList(dao.getTopSellingProducts()));
    }

    private void onRefresh() {
        loadData();
    }

    private void onExportCSV() {
        try (FileWriter writer = new FileWriter("sales_report.csv")) {
            writer.write("Product,Quantity Sold,Revenue\n");
            for (TopProduct tp : dao.getTopSellingProducts()) {
                writer.write(String.format("%s,%d,%.2f\n", tp.getProductName(), tp.getQuantitySold(), tp.getRevenue()));
            }
            showAlert("✅ CSV Exported: sales_report.csv");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("❌ Error exporting CSV: " + e.getMessage());
        }
    }

    private void onBack() {
        HelloApplication.setRoot(new AdminOrdersController());
    }

    private void onLogout() {
        Session.clear();
        HelloApplication.setRoot(new LoginController());
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
