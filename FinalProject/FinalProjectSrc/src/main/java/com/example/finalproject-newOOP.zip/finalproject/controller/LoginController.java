package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.security.JwtService;
import com.example.finalproject.security.Session;
import com.example.finalproject.service.AuthService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class LoginController {
    private TextField emailField;
    private PasswordField passwordField;
    private Label msgLabel;

    private final AuthService authService = new AuthService();

    public Parent createView() {
        // Create main container
        StackPane root = new StackPane();
        root.setPrefSize(800, 600);

        // Create outer VBox for centering
        VBox outerBox = new VBox();
        outerBox.setAlignment(Pos.CENTER);
        outerBox.setSpacing(20);

        // Create inner VBox (auth card)
        VBox authCard = new VBox();
        authCard.setAlignment(Pos.CENTER);
        authCard.setSpacing(12);
        authCard.setMaxWidth(350);
        authCard.getStyleClass().add("auth-card");
        authCard.setPadding(new Insets(30));

        // Title
        Label titleLabel = new Label("🔐 Login");
        titleLabel.getStyleClass().add("title-label");

        // Email field
        emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.getStyleClass().add("text-field");

        // Password field
        passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.getStyleClass().add("password-field");

        // Login button
        Button loginBtn = new Button("Login");
        loginBtn.setPrefWidth(200);
        loginBtn.setOnAction(e -> onLogin());

        // Create Account hyperlink
        Hyperlink registerLink = new Hyperlink("Create Account");
        registerLink.setOnAction(e -> goRegister());

        // Forgot Password hyperlink
        Hyperlink forgotPasswordLink = new Hyperlink("Forgot Password?");
        forgotPasswordLink.setOnAction(e -> onForgotPassword());

        // Message label for errors
        msgLabel = new Label();
        msgLabel.getStyleClass().add("error-label");

        // Add all to auth card
        authCard.getChildren().addAll(
            titleLabel,
            emailField,
            passwordField,
            loginBtn,
            registerLink,
            forgotPasswordLink,
            msgLabel
        );

        outerBox.getChildren().add(authCard);
        root.getChildren().add(outerBox);

        return root;
    }

    public void onLogin() {
        try {
            String token = authService.login(emailField.getText().trim(), passwordField.getText().trim());
            Session.setToken(token);
            String role = JwtService.getRole(token);

            if ("ADMIN".equals(role))
                HelloApplication.setRoot(new AdminProductsController());
            else
                HelloApplication.setRoot(new CustomerHomeController());
        } catch (Exception e) {
            msgLabel.setText(e.getMessage());
        }
    }

    private void onForgotPassword() {
        HelloApplication.setRoot(new ForgotPasswordController());
    }

    public void goRegister() {
        HelloApplication.setRoot(new RegisterController());
    }
}
