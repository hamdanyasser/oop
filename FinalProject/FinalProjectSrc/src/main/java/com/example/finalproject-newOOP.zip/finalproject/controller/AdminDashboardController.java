package com.example.finalproject.controller;

public class AdminDashboardController {
}
