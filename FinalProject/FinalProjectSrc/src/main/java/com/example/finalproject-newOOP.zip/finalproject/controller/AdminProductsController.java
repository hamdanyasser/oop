package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.model.Product;
import com.example.finalproject.security.AuthGuard;
import com.example.finalproject.security.Session;
import com.example.finalproject.service.ProductService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.List;

public class AdminProductsController {

    private TableView<Product> table;
    private TableColumn<Product, Integer> colId;
    private TableColumn<Product, String> colName;
    private TableColumn<Product, String> colCategory;
    private TableColumn<Product, Double> colPrice;
    private TableColumn<Product, Integer> colStock;
    private Label msgLabel;
    private TableColumn<Product, String> colImage;

    private final ProductService productService = new ProductService();
    private final ObservableList<Product> productList = FXCollections.observableArrayList();

    public Parent createView() {
        AuthGuard.requireLogin();

        AnchorPane root = new AnchorPane();
        root.setPrefSize(900, 600);

        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(10));
        AnchorPane.setTopAnchor(vbox, 10.0);
        AnchorPane.setLeftAnchor(vbox, 10.0);
        AnchorPane.setRightAnchor(vbox, 10.0);
        AnchorPane.setBottomAnchor(vbox, 10.0);

        // Title
        Label titleLabel = new Label("🛒 Product Management");
        titleLabel.getStyleClass().add("title-label");

        // Toolbar
        HBox toolbar = new HBox();
        toolbar.setSpacing(10);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        Button addBtn = new Button("Add Product");
        addBtn.setOnAction(e -> onAdd());

        Button editBtn = new Button("Edit Product");
        editBtn.setOnAction(e -> onEdit());

        Button deleteBtn = new Button("Delete Product");
        deleteBtn.setOnAction(e -> onDelete());

        Button reviewsBtn = new Button("⭐ Manage Reviews");
        reviewsBtn.setOnAction(e -> onManageReviews());

        Button promotionsBtn = new Button("💸 Manage Promotions");
        promotionsBtn.setOnAction(e -> onPromotions());

        Button ordersBtn = new Button("View Orders");
        ordersBtn.setOnAction(e -> onOrders());

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button logoutBtn = new Button("Logout");
        logoutBtn.setOnAction(e -> onLogout());

        toolbar.getChildren().addAll(addBtn, editBtn, deleteBtn, reviewsBtn, promotionsBtn, ordersBtn, spacer, logoutBtn);

        // Table
        table = new TableView<>();
        table.setPrefHeight(500);

        colId = new TableColumn<>("ID");
        colId.setPrefWidth(50);
        colId.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getId()).asObject());

        colName = new TableColumn<>("Name");
        colName.setPrefWidth(200);
        colName.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));

        colCategory = new TableColumn<>("Category");
        colCategory.setPrefWidth(150);
        colCategory.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getCategory()));

        colPrice = new TableColumn<>("Price");
        colPrice.setPrefWidth(100);
        colPrice.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getPrice()).asObject());

        colStock = new TableColumn<>("Stock");
        colStock.setPrefWidth(100);
        colStock.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getStock()).asObject());

        colImage = new TableColumn<>("Image");
        colImage.setPrefWidth(100);
        colImage.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getImagePath()));
        colImage.setCellFactory(col -> new TableCell<>() {
            private final ImageView imageView = new ImageView();

            @Override
            protected void updateItem(String path, boolean empty) {
                super.updateItem(path, empty);
                if (empty || path == null || path.isEmpty()) {
                    setGraphic(null);
                } else {
                    imageView.setFitWidth(60);
                    imageView.setFitHeight(60);
                    imageView.setPreserveRatio(true);
                    imageView.setImage(new javafx.scene.image.Image("file:" + path, 60, 60, true, true));
                    setGraphic(imageView);
                }
            }
        });

        table.getColumns().addAll(colId, colName, colCategory, colPrice, colStock, colImage);
        table.setItems(productList);

        // Message label
        msgLabel = new Label();
        msgLabel.getStyleClass().add("error-label");

        vbox.getChildren().addAll(titleLabel, toolbar, table, msgLabel);
        root.getChildren().add(vbox);

        // Load data
        refresh();

        return root;
    }

    // Load all products
    private void refresh() {
        List<Product> products = productService.getAll();
        productList.setAll(products);
        msgLabel.setText("");
    }

    // Add button
    private void onAdd() {
        openProductForm(null);
    }

    // Edit button
    private void onEdit() {
        Product selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            msgLabel.setText("⚠ Select a product to edit.");
            return;
        }
        openProductForm(selected);
    }

    // Delete button
    private void onDelete() {
        Product selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            msgLabel.setText("⚠ Select a product to delete.");
            return;
        }

        try {
            productService.delete(selected.getId());
            refresh();
            msgLabel.setStyle("-fx-text-fill: green;");
            msgLabel.setText("✅ Product deleted successfully!");
        } catch (Exception e) {
            msgLabel.setStyle("-fx-text-fill: red;");
            msgLabel.setText("❌ " + e.getMessage());
        }
    }

    // Open add/edit form
    private void openProductForm(Product product) {
        try {
            ProductFormController controller = new ProductFormController();
            Parent root = controller.createView();
            controller.setProduct(product);
            controller.setOnSaveCallback(this::refresh);

            Stage stage = new Stage();
            stage.setTitle(product == null ? "Add Product" : "Edit Product");
            Scene scene = new Scene(root);
            scene.getStylesheets().add(HelloApplication.class.getResource("view/style.css").toExternalForm());
            stage.setScene(scene);
            stage.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void onManageReviews() {
        HelloApplication.setRoot(new AdminReviewsController());
    }

    private void onOrders() {
        HelloApplication.setRoot(new AdminOrdersController());
    }

    private void onPromotions() {
        HelloApplication.setRoot(new AdminPromotionsController());
    }

    // Logout
    private void onLogout() {
        Session.clear();
        HelloApplication.setRoot(new LoginController());
    }
}
