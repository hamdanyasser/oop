package com.example.finalproject.controller;

import com.example.finalproject.HelloApplication;
import com.example.finalproject.model.Product;
import com.example.finalproject.security.AuthGuard;
import com.example.finalproject.security.Session;
import com.example.finalproject.service.CartService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import java.util.Map;

public class CartController {

    private TableView<CartItem> cartTable;
    private TableColumn<CartItem, String> colName;
    private TableColumn<CartItem, Double> colPrice;
    private TableColumn<CartItem, Integer> colQty;
    private TableColumn<CartItem, Double> colTotal;
    private Label totalLabel;

    private final CartService cartService = CartService.getInstance();

    public Parent createView() {
        AuthGuard.requireLogin();

        BorderPane root = new BorderPane();
        root.setPrefSize(900, 600);

        // Create top bar
        HBox topBar = createTopBar();
        root.setTop(topBar);

        // Create center content
        VBox centerContent = createCenterContent();
        root.setCenter(centerContent);

        // Initial data load
        refreshTable();

        return root;
    }

    private HBox createTopBar() {
        HBox topBar = new HBox();
        topBar.setSpacing(20);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setStyle("-fx-background-color:#0078D7;-fx-padding:12;");

        Label titleLabel = new Label("🛒 Your Cart");
        titleLabel.setStyle("-fx-text-fill:white;-fx-font-size:20px;-fx-font-weight:bold;");

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button backBtn = new Button("🏠 Back to Shop");
        backBtn.setOnAction(e -> onBackToShop());

        Button logoutBtn = new Button("Logout");
        logoutBtn.setOnAction(e -> onLogout());

        topBar.getChildren().addAll(titleLabel, spacer, backBtn, logoutBtn);

        return topBar;
    }

    private VBox createCenterContent() {
        VBox centerContent = new VBox();
        centerContent.setSpacing(15);
        centerContent.setAlignment(Pos.CENTER);
        centerContent.setStyle("-fx-padding:20;");

        // Create table
        cartTable = new TableView<>();
        cartTable.setPrefWidth(700);
        cartTable.setPrefHeight(400);

        // Create columns
        colName = new TableColumn<>("Product");
        colName.setPrefWidth(250);
        colName.setCellValueFactory(data -> data.getValue().nameProperty());

        colPrice = new TableColumn<>("Price ($)");
        colPrice.setPrefWidth(150);
        colPrice.setCellValueFactory(data -> data.getValue().priceProperty().asObject());

        colQty = new TableColumn<>("Quantity");
        colQty.setPrefWidth(120);
        colQty.setCellValueFactory(data -> data.getValue().quantityProperty().asObject());

        colTotal = new TableColumn<>("Subtotal ($)");
        colTotal.setPrefWidth(150);
        colTotal.setCellValueFactory(data -> data.getValue().totalProperty().asObject());

        cartTable.getColumns().addAll(colName, colPrice, colQty, colTotal);

        // Total row
        HBox totalRow = new HBox();
        totalRow.setSpacing(20);
        totalRow.setAlignment(Pos.CENTER_RIGHT);
        totalRow.setPrefWidth(700);

        Label totalTextLabel = new Label("Total:");
        totalTextLabel.setStyle("-fx-font-weight:bold; -fx-font-size:16;");

        totalLabel = new Label();
        totalLabel.setStyle("-fx-font-size:16; -fx-text-fill:#0078D7;");

        totalRow.getChildren().addAll(totalTextLabel, totalLabel);

        // Buttons row
        HBox buttonsRow = new HBox();
        buttonsRow.setSpacing(20);
        buttonsRow.setAlignment(Pos.CENTER);

        Button removeBtn = new Button("🗑 Remove Selected");
        removeBtn.setOnAction(e -> onRemove());

        Button checkoutBtn = new Button("✅ Checkout");
        checkoutBtn.setOnAction(e -> onCheckout());

        buttonsRow.getChildren().addAll(removeBtn, checkoutBtn);

        centerContent.getChildren().addAll(cartTable, totalRow, buttonsRow);

        return centerContent;
    }

    private void refreshTable() {
        ObservableList<CartItem> items = FXCollections.observableArrayList();
        for (Map.Entry<Product, Integer> e : cartService.getItems().entrySet()) {
            items.add(new CartItem(e.getKey(), e.getValue()));
        }
        cartTable.setItems(items);
        totalLabel.setText(String.format("$%.2f", cartService.getTotal()));
    }

    private void onRemove() {
        CartItem selected = cartTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            cartService.removeItem(selected.getProduct());
            refreshTable();
        } else {
            showAlert("No selection", "Please select an item to remove.");
        }
    }

    private void onCheckout() {
        if (cartService.getItems().isEmpty()) {
            showAlert("Cart is empty!", "Add some items first.");
            return;
        }
        HelloApplication.setRoot(new CheckoutController());
    }

    private void onBackToShop() {
        HelloApplication.setRoot(new CustomerHomeController());
    }

    private void onLogout() {
        Session.clear();
        HelloApplication.setRoot(new LoginController());
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
